// ── LISTAI PRO v2 — Popup ────────────────────────────────────────────────────

const SUPA_URL = "https://csdbtnfachdxafczqnal.supabase.co";
const SUPA_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNzZGJ0bmZhY2hkeGFmY3pxbmFsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE4MDA0MDQsImV4cCI6MjA5NzM3NjQwNH0.qa7YXHxjnCji0MXHvb5_geSiqAd1MlBc9B2RhUd4wpE";

let selectedListing = null;
let state = {};
let isDark = false;

// ── THÈME ────────────────────────────────────────────────────────────────────
function applyTheme(dark) {
  isDark = dark;
  document.body.setAttribute('data-dark', dark ? 'true' : 'false');
  document.getElementById('btn-theme').textContent = dark ? '☀️' : '🌙';
  chrome.storage.local.set({ theme: dark ? 'dark' : 'light' });
}

document.getElementById('btn-theme').addEventListener('click', () => applyTheme(!isDark));

// Charge le thème sauvegardé
chrome.storage.local.get('theme', ({ theme }) => {
  applyTheme(theme === 'dark');
});

// ── TUTORIEL ─────────────────────────────────────────────────────────────────
const TUTO_STEPS = [
  { icon: '✦', title: 'Bienvenue sur ListAI Pro !', desc: 'Ton assistant IA pour publier tes annonces Vinted automatiquement. Ce tutoriel te guide en 5 étapes.' },
  { icon: '☁️', title: 'Synchronise d\'abord', desc: 'Ouvre listai-pro-virid.vercel.app dans Chrome, connecte-toi, puis reviens ici et clique sur "⟳ Sync" pour charger tes annonces.' },
  { icon: '📤', title: 'Publie tes annonces', desc: 'Dans l\'onglet "Publier", sélectionne une annonce générée par ListAI et clique "🚀 Publier sur Vinted". L\'extension remplit tout automatiquement !' },
  { icon: '⚙️', title: 'Configure l\'agent', desc: 'Dans "Agent", active les automatisations : baisse de prix auto, gestion des offres, réponses aux acheteurs.' },
  { icon: '📦', title: 'Suis ton stock', desc: 'L\'onglet "Stock" affiche tous tes articles synchronisés depuis ListAI. Le Journal enregistre toutes les actions effectuées.' },
];

let tutoStep = 0;

function showTuto() {
  document.getElementById('tuto-overlay').style.display = 'flex';
  renderTutoStep();
}

function renderTutoStep() {
  const step = TUTO_STEPS[tutoStep];
  document.getElementById('tuto-icon').textContent = step.icon;
  document.getElementById('tuto-step').textContent = `Étape ${tutoStep + 1} / ${TUTO_STEPS.length}`;
  document.getElementById('tuto-title').textContent = step.title;
  document.getElementById('tuto-desc').textContent = step.desc;
  document.getElementById('tuto-next').textContent = tutoStep < TUTO_STEPS.length - 1 ? 'Suivant →' : '✓ Commencer !';

  // Dots
  const dots = document.getElementById('tuto-dots');
  dots.innerHTML = TUTO_STEPS.map((_, i) => `<div class="tuto-dot ${i === tutoStep ? 'active' : ''}"></div>`).join('');
}

document.getElementById('tuto-next').addEventListener('click', () => {
  if (tutoStep < TUTO_STEPS.length - 1) { tutoStep++; renderTutoStep(); }
  else { document.getElementById('tuto-overlay').style.display = 'none'; chrome.storage.local.set({ tutoSeen: true }); }
});

document.getElementById('tuto-skip').addEventListener('click', () => {
  document.getElementById('tuto-overlay').style.display = 'none';
  chrome.storage.local.set({ tutoSeen: true });
});

document.getElementById('btn-tuto').addEventListener('click', () => { tutoStep = 0; showTuto(); });

// Affiche le tuto au premier lancement
chrome.storage.local.get('tutoSeen', ({ tutoSeen }) => { if (!tutoSeen) showTuto(); });

// ── TABS ─────────────────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.content').forEach(c => c.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
  });
});

// ── SUPABASE SYNC ─────────────────────────────────────────────────────────────
async function syncFromSupabase() {
  try {
    const tabs = await new Promise(r => chrome.tabs.query({ url: 'https://listai-pro-virid.vercel.app/*' }, r));
    if (tabs.length === 0) return { ok: false, reason: 'Ouvre listai-pro-virid.vercel.app dans Chrome' };

    const results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => JSON.parse(localStorage.getItem('listai_session') || 'null')
    });

    const session = results?.[0]?.result;
    if (!session?.access_token) return { ok: false, reason: 'Connecte-toi sur listai-pro-virid.vercel.app' };

    chrome.storage.local.set({ supabase_session: session });
    const uid = session.user.id;
    const tok = session.access_token;

    const [listings, stock] = await Promise.all([
      fetch(`${SUPA_URL}/rest/v1/listings?user_id=eq.${uid}&order=created_at.desc&limit=200`, { headers: { apikey: SUPA_KEY, Authorization: `Bearer ${tok}`, 'Range-Unit': 'items', 'Prefer': 'count=none' } }).then(r => r.json()),
      fetch(`${SUPA_URL}/rest/v1/stock?user_id=eq.${uid}&order=created_at.desc&limit=200`, { headers: { apikey: SUPA_KEY, Authorization: `Bearer ${tok}`, 'Range-Unit': 'items', 'Prefer': 'count=none' } }).then(r => r.json())
    ]);

    const syncedStock = Array.isArray(stock) ? stock.map(s => ({ ...s, dateAjout: s.date_ajout })) : [];

    // Titres des articles déjà en stock (en_vente ou autre) → à exclure des listings à publier
    const titresEnStock = new Set(
      syncedStock.filter(s => s.statut === 'en_vente' || s.statut === 'reserve' || s.statut === 'vendu')
                 .map(s => s.titre?.toLowerCase().trim())
                 .filter(Boolean)
    );

    // Pour chaque listing : exclure ceux déjà en stock, récupérer photo si manquante
    // Filtre les articles déjà en vente dans le stock (évite doublons)
    const titresDejaEnVente = new Set(
      syncedStock
        .filter(s => s.statut === 'en_vente' || s.statut === 'reserve')
        .map(s => s.titre?.toLowerCase().trim())
        .filter(Boolean)
    );
    const syncedListings = Array.isArray(listings) ? listings
      .map(l => {
        let photo = l.photo || '';
        if (!photo && l.result?.titre) {
          const match = syncedStock.find(s => s.titre === l.result?.titre);
          if (match?.photo) photo = match.photo;
        }
        return { id: l.id, date: l.date, result: l.result, photo };
      })
      .filter(l => {
        // Exclut si déjà en vente dans le stock
        const titre = l.result?.titre?.toLowerCase().trim();
        return titre && !titresDejaEnVente.has(titre);
      }) : [];

    chrome.storage.local.set({ syncedListings, syncedStock });
    return { ok: true, listings: syncedListings.length, stock: syncedStock.length };
  } catch (e) { return { ok: false, reason: e.message }; }
}

// ── LOAD STATE ────────────────────────────────────────────────────────────────
function loadState() {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, data => {
    if (!data) return;
    state = data;
    renderDashboard(data);
    renderPublish(data);
    renderAgent(data);
    renderStock(data);
    renderLog(data);
  });
}

// ── DASHBOARD ─────────────────────────────────────────────────────────────────
function renderDashboard(data) {
  const { stats, settings, alerts, syncedStock, syncedListings } = data;
  const active = settings?.autoMessages || settings?.autoOffers || settings?.autoPriceDrop;
  document.getElementById('dot').style.background = active ? 'var(--green)' : 'var(--text3)';
  document.getElementById('s-msg').textContent = stats?.msgSent || 0;
  document.getElementById('s-offers').textContent = stats?.offersSent || 0;
  document.getElementById('s-accepted').textContent = stats?.offersAccepted || 0;
  document.getElementById('s-sales').textContent = stats?.salesDetected || 0;

  const stockLen = syncedStock?.length || 0;
  const listingsLen = syncedListings?.length || 0;
  document.getElementById('sync-sub').innerHTML = stockLen > 0
    ? `<strong>✓ Sync</strong> — ${stockLen} articles · ${listingsLen} annonces`
    : 'Non synchronisé — clique Sync';

  const alertsList = document.getElementById('alerts-list');
  if (alerts?.length > 0) {
    alertsList.innerHTML = alerts.slice(0, 5).map(a => `
      <div class="alert-item">
        <div class="alert-title">⚠️ ${a.titre}</div>
        <div class="alert-sub">En vente depuis ${a.days} jours</div>
      </div>`).join('');
  } else {
    alertsList.innerHTML = '<div class="empty"><div class="empty-icon">✅</div><div class="empty-title">Tout va bien !</div><div class="empty-sub">Aucun article sans activité</div></div>';
  }
}

// ── PUBLISH ───────────────────────────────────────────────────────────────────
function renderPublish(data) {
  // Filtre les articles déjà publiés (permanent même après re-sync)
  const publishedSet = new Set([
    ...(data.publishedTitles||[]),
    ...(data.log||[]).filter(l=>l.action==='published').map(l=>l.target)
  ]);
  const listings = (data.syncedListings || []).filter(l => !publishedSet.has(l.result?.titre));
  const listingsEl = document.getElementById('listings-list');
  const pubQueue = data.publishQueue || [];
  const queueInfoEl = document.getElementById('pub-queue-info');
  const launchBtn = document.getElementById('btn-start-queue');
  if (pubQueue.length > 0) {
    queueInfoEl.innerHTML = pubQueue.map((l, i) => `
      <div class="queue-item">
        <div style="display:flex;align-items:center;min-width:0;">
          ${l.photo ? `<img src="${l.photo}" style="width:26px;height:26px;border-radius:5px;object-fit:cover;margin-right:6px;flex-shrink:0;">` : '<span style="margin-right:6px;font-size:14px;">👕</span>'}
          <span class="queue-item-num">#${i+1}</span>
          <span class="queue-item-title">${(l.titre||'Annonce').slice(0,28)}</span>
        </div>
        <button class="queue-remove" data-idx="${i}">✕</button>
      </div>`).join('');
    // Attacher les listeners sur les boutons supprimer (évite onclick inline bloqué dans popup)
    queueInfoEl.querySelectorAll('.queue-remove').forEach(btn => {
      btn.addEventListener('click', () => removeFromQueue(parseInt(btn.dataset.idx)));
    });
    launchBtn.textContent = `🚀 Lancer la publication (${pubQueue.length})`;
    launchBtn.disabled = false;
    launchBtn.style.opacity = '1';
  } else {
    queueInfoEl.innerHTML = '<div style="font-size:11px;color:var(--text2);">File vide — ajoute des annonces ci-dessus</div>';
    launchBtn.textContent = '🚀 Lancer la publication';
    launchBtn.disabled = true;
    launchBtn.style.opacity = '0.4';
  }

  if (listings.length === 0) {
    listingsEl.innerHTML = '<div class="empty"><div class="empty-icon">📝</div><div class="empty-title">Aucune annonce</div><div class="empty-sub">Génère des annonces sur ListAI Pro puis synchronise</div></div>';
    return;
  }

  listingsEl.innerHTML = listings.map((h, i) => `
    <div class="listing-card" data-idx="${i}">
      <div style="display:flex;gap:8px;align-items:center;">
        ${h.photo ? `<img src="${h.photo}" style="width:36px;height:36px;border-radius:7px;object-fit:cover;flex-shrink:0;">` : '<div style="width:36px;height:36px;border-radius:7px;background:#e5e5ea;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;">👕</div>'}
        <div style="flex:1;min-width:0;">
          <div class="listing-title">${h.result?.titre || 'Annonce'}</div>
          <div class="listing-meta">${h.date || ''} · ${h.result?.prix_recommande || '?'}€ · ${h.result?.marque || ''}</div>
        </div>
      </div>
    </div>`).join('');

  document.querySelectorAll('.listing-card').forEach((card, i) => {
    card.addEventListener('click', () => {
      selectedListing = listings[i];
      document.querySelectorAll('.listing-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      document.getElementById('publish-actions').style.display = 'block';
      const infoEl = document.getElementById('selected-info');
      if (infoEl) infoEl.textContent = (selectedListing.result?.titre || 'Annonce') + ' — ' + (selectedListing.result?.prix_recommande || '?') + '€';
    });
  });
}

// ── AGENT ─────────────────────────────────────────────────────────────────────
let _lastSettings = null;
function renderAgent(data) {
  const s = data.settings || {};
  // Ne réinitialise pas si l'utilisateur est en train de modifier
  const settingsStr = JSON.stringify(s);
  if (_lastSettings === settingsStr) return; // rien de changé → skip
  _lastSettings = settingsStr;

  document.getElementById('t-autoprice').checked = s.autoPriceDrop || false;
  document.getElementById('t-offers').checked = s.autoOffers || false;
  document.getElementById('t-accept').checked = s.autoAcceptOffers !== false;
  document.getElementById('t-reply').checked = s.autoMessages || false;
  setSlider('drop-pct', s.priceDropPct || 10, v => `${v}%`);
  setSlider('drop-days', s.priceDropDays || 7, v => `${v} jours`);
  setSlider('threshold', s.offerThreshold || 80, v => `${v}%`);
  setSlider('counter-pct', s.offerCounterPct || 90, v => `${v}%`);

  const schedList = document.getElementById('schedule-list');
  const stock = data.syncedStock?.filter(s => s.statut === 'en_vente') || [];
  if (stock.length > 0) {
    schedList.innerHTML = stock.slice(0, 5).map(item => `
      <div class="schedule-item">
        <div>
          <div class="stock-title">${item.titre}</div>
          <div class="stock-meta">${item.prix || '?'}€</div>
        </div>
        <button onclick="triggerDrop('${item.id}','${item.titre}','${item.prix}')" 
          class="btn btn-outline btn-sm" style="width:auto;margin:0;">📉 Baisser</button>
      </div>`).join('');
  } else {
    schedList.innerHTML = '<div class="empty"><div class="empty-sub">Synchronise pour voir tes articles</div></div>';
  }
}

window.triggerDrop = (id, titre, prix) => {
  chrome.runtime.sendMessage({ type: 'TRIGGER_PRICE_DROP', item: { id, titre, prix } }, () => showToast('📉 Baisse lancée !'));
};

// ── STOCK ─────────────────────────────────────────────────────────────────────
function renderStock(data) {
  const stock = data.syncedStock || [];
  const selling = stock.filter(s => s.statut === 'en_vente');
  const sold = stock.filter(s => s.statut === 'vendu');
  const ca = sold.reduce((sum, s) => sum + (parseFloat(s.prix) || 0), 0);
  document.getElementById('stock-selling').textContent = selling.length;
  document.getElementById('stock-sold').textContent = sold.length;
  document.getElementById('stock-ca').textContent = `${ca.toFixed(0)}€`;

  const listEl = document.getElementById('stock-list');
  if (stock.length === 0) {
    listEl.innerHTML = '<div class="empty"><div class="empty-icon">📦</div><div class="empty-sub">Synchronise l\'app pour voir ton stock</div></div>';
    return;
  }
  listEl.innerHTML = stock.slice(0, 10).map(s => {
    const badge = s.statut === 'vendu' ? 'badge-green' : s.statut === 'reserve' ? 'badge-yellow' : 'badge-blue';
    const label = s.statut === 'vendu' ? 'Vendu' : s.statut === 'reserve' ? 'Réservé' : 'En vente';
    return `
      <div class="stock-item">
        <div>
          <div class="stock-title">${s.titre}</div>
          <div class="stock-meta">${s.marque || ''} · ${s.taille || ''}</div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
          <span style="font-size:13px;font-weight:800;color:var(--gold);">${s.prix || '?'}€</span>
          <span class="badge ${badge}">${label}</span>
        </div>
      </div>`;
  }).join('');
}

// ── LOG ───────────────────────────────────────────────────────────────────────
function renderLog(data) {
  const logEl = document.getElementById('log-list');
  const log = data.log || [];
  if (log.length === 0) {
    logEl.innerHTML = '<div class="empty"><div class="empty-icon">🕓</div><div class="empty-sub">Aucune action enregistrée</div></div>';
    return;
  }
  const icons = { message:'📨', offer:'🤝', offer_accepted:'✅', price_drop:'📉', published:'📝', sale_detected:'💰' };
  logEl.innerHTML = log.slice(0, 30).map(item => `
    <div class="log-item">
      <div>
        <div class="log-action">${icons[item.action] || '•'} ${item.target || item.action}</div>
        ${item.price ? `<div class="log-detail">${item.price}€</div>` : ''}
      </div>
      <div class="log-time">${new Date(item.ts).toLocaleTimeString('fr-FR', {hour:'2-digit',minute:'2-digit'})}</div>
    </div>`).join('');
}

// ── HELPERS ───────────────────────────────────────────────────────────────────
function setSlider(id, value, format) {
  const el = document.getElementById(id);
  const valEl = document.getElementById(`${id}-val`);
  if (el) el.value = value;
  if (valEl) valEl.textContent = format ? format(value) : value;
}

function liveSlider(id, format) {
  const el = document.getElementById(id);
  const valEl = document.getElementById(`${id}-val`);
  if (el && valEl) el.addEventListener('input', e => { valEl.textContent = format ? format(e.target.value) : e.target.value; });
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.display = 'block';
  setTimeout(() => { t.style.display = 'none'; }, 2500);
}

async function getVintedTab() {
  return new Promise(r => chrome.tabs.query({ url: ['https://www.vinted.fr/*','https://www.vinted.be/*'] }, tabs => r(tabs[0] || null)));
}

// ── LIVE SLIDERS ──────────────────────────────────────────────────────────────
liveSlider('drop-pct', v => `${v}%`);
liveSlider('drop-days', v => `${v} jours`);
liveSlider('threshold', v => `${v}%`);
liveSlider('counter-pct', v => `${v}%`);
liveSlider('daily-limit', v => v);
liveSlider('delay', v => `${v}s`);

// ── BOUTON SYNC ───────────────────────────────────────────────────────────────
document.getElementById('btn-sync').addEventListener('click', async () => {
  const btn = document.getElementById('btn-sync');
  btn.textContent = '⟳ Sync...'; btn.disabled = true;
  const result = await syncFromSupabase();
  if (result.ok) {
    showToast(`✓ ${result.listings} annonces · ${result.stock} articles !`);
  } else {
    showToast(`❌ ${result.reason}`);
  }
  btn.textContent = '⟳ Sync'; btn.disabled = false;
  setTimeout(loadState, 500);
});

// ── DASHBOARD BUTTONS ─────────────────────────────────────────────────────────
document.getElementById('btn-scan').addEventListener('click', async () => {
  const btn = document.getElementById('btn-scan');
  btn.textContent = '⟳ Scan...'; btn.disabled = true;
  const tab = await getVintedTab();
  if (!tab) { chrome.tabs.create({ url: 'https://www.vinted.fr/member/items' }); }
  else {
    chrome.tabs.sendMessage(tab.id, { type: 'SCAN_FAVORITES' }, res => {
      const items = res?.items || [];
      if (!items.length) { showToast('Aucun favori détecté'); }
      else {
        chrome.runtime.sendMessage({ type: 'ADD_TO_QUEUE', items }, r => {
          showToast(r?.added > 0 ? `✓ ${r.added} article(s) en file` : 'Déjà en file');
          loadState();
        });
      }
    });
  }
  setTimeout(() => { btn.textContent = '🔍 Scanner les favoris'; btn.disabled = false; }, 2000);
});

document.getElementById('btn-scan-offers').addEventListener('click', async () => {
  const tab = await getVintedTab();
  if (tab) { chrome.tabs.sendMessage(tab.id, { type: 'SCAN_FOR_ACTIVITY', settings: state.settings || {} }); showToast('Scan des offres lancé !'); }
  else { chrome.tabs.create({ url: 'https://www.vinted.fr' }); }
});

document.getElementById('btn-stop').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'STOP_ALL' }, () => { showToast('✓ Tout arrêté'); setTimeout(loadState, 500); });
});

// ── PUBLISH BUTTONS ───────────────────────────────────────────────────────────
document.getElementById('btn-publish').addEventListener('click', () => {
  if (!selectedListing) return;
  // Nettoie le prix avant envoi
  const rawPrixP = selectedListing.result?.prix_recommande || selectedListing.result?.prix || '';
  const cleanPrix = String(rawPrixP).replace(/[^0-9.,]/g,'').replace(',','.') || '';
  const listing = {
    titre: selectedListing.result?.titre,
    description: selectedListing.result?.description,
    prix_recommande: cleanPrix,
    prix: cleanPrix,
    marque: selectedListing.result?.marque,
    taille: selectedListing.result?.taille,
    etat: selectedListing.result?.etat,
    categorie: selectedListing.result?.categorie,
    sous_categorie: selectedListing.result?.sous_categorie,
    couleur: selectedListing.result?.couleur,
    stockId: selectedListing.stockId || null,
    id: selectedListing.id || null
  };
  console.log('[ListAI Popup] Annonce ajoutée:', listing.titre, 'Prix:', listing.prix_recommande);
  chrome.runtime.sendMessage({ type: 'PUBLISH_LISTING', listing, mode: 'direct' }, () => showToast('🚀 Publication lancée !'));
});

document.getElementById('btn-add-queue').addEventListener('click', () => {
  if (!selectedListing) return;
  // Nettoie le prix avant envoi
  const rawPrixP = selectedListing.result?.prix_recommande || selectedListing.result?.prix || '';
  const cleanPrix = String(rawPrixP).replace(/[^0-9.,]/g,'').replace(',','.') || '';
  const listing = {
    titre: selectedListing.result?.titre,
    description: selectedListing.result?.description,
    prix_recommande: cleanPrix,
    prix: cleanPrix,
    marque: selectedListing.result?.marque,
    taille: selectedListing.result?.taille,
    etat: selectedListing.result?.etat,
    categorie: selectedListing.result?.categorie,
    sous_categorie: selectedListing.result?.sous_categorie,
    couleur: selectedListing.result?.couleur,
    stockId: selectedListing.stockId || null,
    id: selectedListing.id || null
  };
  console.log('[ListAI Popup] Annonce ajoutée:', listing.titre, 'Prix:', listing.prix_recommande);
  listing.photo = selectedListing.photo || '';
  // Nettoyer le prix avant de mettre en file (évite NaN)
  const rawPrixQ = listing.prix_recommande ?? listing.prix ?? '';
  listing.prix = String(rawPrixQ).replace(/[^0-9.,]/g, '').replace(',', '.') || '';
  listing.prix_recommande = listing.prix;
  chrome.runtime.sendMessage({ type: 'ADD_TO_PUBLISH_QUEUE', listings: [listing] }, () => {
    showToast('✓ Ajouté à la file');
    setTimeout(loadState, 300);
  });
});

// Supprimer de la file
window.removeFromQueue = (idx) => {
  chrome.storage.local.get('publishQueue', ({ publishQueue }) => {
    const updated = (publishQueue||[]).filter((_,i) => i !== idx);
    chrome.storage.local.set({ publishQueue: updated }, () => {
      showToast('✕ Retiré de la file');
      setTimeout(loadState, 200);
    });
  });
};

// Lancer la file manuellement
function startQueue() {
  chrome.storage.local.get('publishQueue', ({ publishQueue }) => {
    if (!publishQueue?.length) { showToast('File vide !'); return; }
    const [current, ...rest] = publishQueue;
    chrome.storage.local.set({ publishQueue: rest, pendingListing: current, publishMode: 'direct' });
    chrome.tabs.query({ url: ['https://www.vinted.fr/*','https://www.vinted.be/*'] }, tabs => {
      if (tabs.length > 0) {
        if (tabs[0].url.includes('/items/new')) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'DO_PUBLISH', listing: current, mode: 'direct' });
        } else {
          chrome.tabs.update(tabs[0].id, { url: 'https://www.vinted.fr/items/new' });
        }
      } else {
        chrome.tabs.create({ url: 'https://www.vinted.fr/items/new' });
      }
    });
    showToast('🚀 Publication lancée !');
    setTimeout(loadState, 500);
  });
}

// ── AGENT SAVE ────────────────────────────────────────────────────────────────
document.getElementById('btn-save-agent').addEventListener('click', () => {
  const payload = {
    autoPriceDrop: document.getElementById('t-autoprice').checked,
    autoOffers: document.getElementById('t-offers').checked,
    autoAcceptOffers: document.getElementById('t-accept').checked,
    autoMessages: document.getElementById('t-reply').checked, // correct key
    priceDropPct: parseInt(document.getElementById('drop-pct').value),
    priceDropDays: parseInt(document.getElementById('drop-days').value),
    offerThreshold: parseInt(document.getElementById('threshold').value),
    offerCounterPct: parseInt(document.getElementById('counter-pct').value),
  };
  chrome.runtime.sendMessage({ type: 'SET_SETTINGS', payload }, () => { showToast('✓ Enregistré !'); setTimeout(loadState, 300); });
});

// ── SETTINGS SAVE ─────────────────────────────────────────────────────────────
document.getElementById('btn-save-settings').addEventListener('click', () => {
  const payload = {
    dailyLimit: parseInt(document.getElementById('daily-limit').value),
    delayBetween: parseInt(document.getElementById('delay').value) * 1000
  };
  chrome.runtime.sendMessage({ type: 'SET_SETTINGS', payload }, () => { showToast('✓ Limites enregistrées !'); });
});

document.getElementById('btn-clear-log').addEventListener('click', () => {
  chrome.storage.local.set({ log: [] }, () => { showToast('Journal vidé'); setTimeout(loadState, 300); });
});

// ── INIT ──────────────────────────────────────────────────────────────────────
// Recharge l'état quand une action est complétée (publication, etc.)
chrome.storage.onChanged.addListener((changes) => {
  if (changes.syncedListings || changes.publishQueue || changes.syncedStock) {
    loadState();
  }
});

document.getElementById('btn-start-queue').addEventListener('click', startQueue);
document.getElementById('btn-sync2')?.addEventListener('click', async () => {
  const btn = document.getElementById('btn-sync2');
  btn.textContent = '⟳...'; btn.disabled = true;
  const result = await syncFromSupabase();
  showToast(result.ok ? `✓ ${result.listings} annonces !` : `❌ ${result.reason}`);
  btn.textContent = '⟳ Sync'; btn.disabled = false;
  setTimeout(loadState, 500);
});
loadState();
setInterval(loadState, 5000);
