// ── LISTAI PRO v2 — Background ───────────────────────────────────────────────

const SUPA_URL = "https://csdbtnfachdxafczqnal.supabase.co";
const SUPA_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNzZGJ0bmZhY2hkeGFmY3pxbmFsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE4MDA0MDQsImV4cCI6MjA5NzM3NjQwNH0.qa7YXHxjnCji0MXHvb5_geSiqAd1MlBc9B2RhUd4wpE";

// ── MET À JOUR OU CRÉE UN ARTICLE DANS LE STOCK SUPABASE ────────────────────
async function markStockAsEnVente(titre, session, listingData) {
  try {
    if (!session?.access_token || !session?.user?.id) {
      console.warn('[ListAI] Pas de session Supabase pour sync stock');
      return false;
    }
    const uid = session.user.id;
    const tok = session.access_token;
    const headers = { apikey: SUPA_KEY, Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', Accept: 'application/json' };

    // 1. Cherche l'article par titre dans la table stock
    const searchRes = await fetch(
      `${SUPA_URL}/rest/v1/stock?user_id=eq.${encodeURIComponent(uid)}&titre=eq.${encodeURIComponent(titre)}&select=id,statut`,
      { headers }
    );
    const rows = await searchRes.json();

    if (Array.isArray(rows) && rows.length > 0) {
      // ── Existe déjà → mettre à jour statut + photo ─────────────────────
      const patchData = { statut: 'en_vente' };
      if (listingData?.photo) patchData.photo = listingData.photo;
      const patchRes = await fetch(`${SUPA_URL}/rest/v1/stock?id=eq.${rows[0].id}`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify(patchData)
      });
      console.log('[ListAI] ✅ Stock PATCH statut:', patchRes.status, titre);
    } else {
      // ── N'existe pas → créer l'entrée dans le stock ──────────────────────
      const newStock = {
        user_id: uid,
        titre: titre,
        marque: listingData?.marque || '',
        taille: listingData?.taille || '',
        prix: String(listingData?.prix_recommande || listingData?.prix || ''),
        plateforme: 'Vinted',
        etat: listingData?.etat || '',
        notes: '',
        statut: 'en_vente',
        date_ajout: new Date().toISOString().split('T')[0],
        photo: listingData?.photo || '',
        updated_at: new Date().toISOString()
      };
      await fetch(`${SUPA_URL}/rest/v1/stock`, {
        method: 'POST',
        headers: { ...headers, Prefer: 'return=minimal' },
        body: JSON.stringify(newStock)
      });
      console.log('[ListAI] ✅ Stock créé → en_vente:', titre);
    }
    return true;
  } catch (e) {
    console.error('[ListAI] Erreur sync Supabase stock:', e);
    return false;
  }
}

const DEFAULT_SETTINGS = {
  autoMessages: false, autoOffers: false, autoPriceDrop: false,
  priceDropPct: 10, priceDropDays: 7, offerThreshold: 80,
  offerCounterPct: 90, autoAcceptOffers: true, delayBetween: 15000, dailyLimit: 50,
};

function today() { return new Date().toISOString().split('T')[0]; }

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    settings: DEFAULT_SETTINGS, queue: [], publishQueue: [],
    priceDropSchedule: [], stats: { msgSent:0, offersSent:0, offersAccepted:0, salesDetected:0, today:today() },
    log: [], syncedStock: [], syncedListings: [], alerts: [],
  });
  notify('ListAI Pro v2 ✦', 'Extension installée !');
});

// ── MESSAGES ─────────────────────────────────────────────────────────────────
// ── TYPE IN CATEGORY via chrome.debugger ────────────────────────────────────
async function typeInCategoryDebugger(tabId, text) {
  try {
    await chrome.debugger.attach({ tabId }, '1.3');
    await new Promise(r => setTimeout(r, 500));

    // Récupère les coordonnées de #catalog-search-input
    const result = await chrome.debugger.sendCommand({ tabId }, 'Runtime.evaluate', {
      expression: `
        (function() {
          const el = document.querySelector('#catalog-search-input');
          if (!el) return null;
          const r = el.getBoundingClientRect();
          return { x: r.left + r.width/2, y: r.top + r.height/2 };
        })()
      `,
      returnByValue: true
    });

    const coords = result?.result?.value;
    if (coords) {
      // Clic physique sur la barre de recherche via debugger
      await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
        type: 'mouseMoved', x: coords.x, y: coords.y
      });
      await new Promise(r => setTimeout(r, 100));
      await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
        type: 'mousePressed', x: coords.x, y: coords.y, button: 'left', clickCount: 1
      });
      await new Promise(r => setTimeout(r, 100));
      await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
        type: 'mouseReleased', x: coords.x, y: coords.y, button: 'left', clickCount: 1
      });
      await new Promise(r => setTimeout(r, 500));
    }

    // Tape le texte avec Input.insertText (méthode native navigateur)
    await chrome.debugger.sendCommand({ tabId }, 'Input.insertText', { text });
    await new Promise(r => setTimeout(r, 200));
    
    // Déclenche aussi un event input pour React
    await chrome.debugger.sendCommand({ tabId }, 'Runtime.evaluate', {
      expression: `
        (function() {
          const el = document.querySelector('#catalog-search-input');
          if (el) {
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
          }
        })()
      `
    });

    await new Promise(r => setTimeout(r, 2000));
    await chrome.debugger.detach({ tabId });
    return true;
  } catch (e) {
    try { await chrome.debugger.detach({ tabId }); } catch {}
    console.warn('[ListAI] debugger:', e);
    return false;
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {

    case 'GET_STATE':
      chrome.storage.local.get(null, data => sendResponse(data));
      return true;

    case 'SET_SETTINGS':
      chrome.storage.local.get('settings', ({ settings }) => {
        chrome.storage.local.set({ settings: { ...settings, ...msg.payload } });
        sendResponse({ ok: true });
      });
      return true;

    case 'SYNC_FROM_APP':
      chrome.storage.local.set({ syncedStock: msg.stock||[], syncedListings: msg.listings||[] }, () => {
        checkStaleItems(msg.stock||[]);
        sendResponse({ ok: true, synced: (msg.stock||[]).length });
      });
      return true;

    case 'ADD_TO_QUEUE':
      chrome.storage.local.get(['queue','stats','settings'], data => {
        const stats = resetDay(data.stats);
        if (stats.msgSent >= (data.settings?.dailyLimit||50)) { sendResponse({ ok:false, reason:'Limite journalière' }); return; }
        const existing = new Set(data.queue.map(i => i.id));
        const newItems = (msg.items||[]).filter(i => !existing.has(i.id));
        chrome.storage.local.set({ queue: [...data.queue, ...newItems], stats });
        if (newItems.length > 0) chrome.alarms.create('processQueue', { delayInMinutes: 0.1 });
        sendResponse({ ok: true, added: newItems.length });
      });
      return true;

    // ── FILE DE PUBLICATION ──────────────────────────────────────────────────
    case 'ADD_TO_PUBLISH_QUEUE':
      chrome.storage.local.get('publishQueue', ({ publishQueue }) => {
        const updated = [...(publishQueue||[]), ...msg.listings];
        chrome.storage.local.set({ publishQueue: updated });
        sendResponse({ ok: true, queued: msg.listings.length });
        // ⚠️ Pas de lancement auto — attend le bouton manuel du popup
      });
      return true;

    case 'PUBLISH_LISTING': {
      const listing = msg.listing;
      const mode = msg.mode || 'direct';
      const draftUrl = msg.draftUrl || null;
      
      chrome.tabs.query({ url: ['https://www.vinted.fr/*'] }, tabs => {
        const vintedTab = tabs[0];
        
        if (mode === 'auto') {
          // Mode Auto : l'utilisateur est déjà sur sa page profil
          // On récupère l'ID du membre depuis l'URL ou depuis les données de la page
          chrome.storage.local.set({ pendingListing: listing, publishMode: 'auto' });
          if (vintedTab) {
            chrome.scripting.executeScript({
              target: { tabId: vintedTab.id },
              func: () => {
                // Récupère l'ID depuis l'URL courante si c'est une page membre
                const memberMatch = window.location.href.match(/member\/(\d+)/);
                if (memberMatch) return memberMatch[1];
                // Sinon cherche dans les données Next.js
                const nextData = window.__NEXT_DATA__?.props?.pageProps;
                return nextData?.currentUser?.id || nextData?.user?.id || null;
              }
            }, results => {
              const memberId = results?.[0]?.result;
              if (memberId) {
                // Va sur la page profil du membre
                const profileUrl = `https://www.vinted.fr/member/${memberId}`;
                chrome.storage.local.set({ pendingListing: listing, publishMode: 'auto' });
                if (vintedTab.url.includes(`/member/${memberId}`)) {
                  // Déjà sur la page profil → envoie directement
                  chrome.tabs.sendMessage(vintedTab.id, { type: 'DO_PUBLISH', listing, mode: 'auto' });
                } else {
                  chrome.tabs.update(vintedTab.id, { url: profileUrl });
                }
              } else {
                // Fallback : envoie sur la page courante
                chrome.tabs.sendMessage(vintedTab.id, { type: 'DO_PUBLISH', listing, mode: 'auto' });
              }
            });
          } else {
            chrome.tabs.create({ url: 'https://www.vinted.fr' });
          }
        } else if (mode === 'manual' && draftUrl) {
          // Mode Manuel : va directement sur le brouillon
          if (vintedTab) {
            chrome.storage.local.set({ pendingListing: listing, publishMode: 'manual' });
            chrome.tabs.update(vintedTab.id, { url: draftUrl });
          } else {
            chrome.storage.local.set({ pendingListing: listing, publishMode: 'manual' });
            chrome.tabs.create({ url: draftUrl });
          }
        } else {
          // Mode Direct : va sur /items/new
          if (vintedTab) {
            chrome.storage.local.set({ pendingListing: listing, publishMode: 'direct' });
            if (vintedTab.url.includes('/items/new')) {
              chrome.tabs.sendMessage(vintedTab.id, { type: 'DO_PUBLISH', listing, mode: 'direct' });
            } else {
              chrome.tabs.update(vintedTab.id, { url: 'https://www.vinted.fr/items/new' });
            }
          } else {
            chrome.storage.local.set({ pendingListing: listing, publishMode: 'direct' });
            chrome.tabs.create({ url: 'https://www.vinted.fr/items/new' });
          }
        }
      });
      sendResponse({ ok: true });
      return true;
    }

    // Enchaînement géré directement dans ACTION_DONE via triggerNext
    case 'NEXT_IN_QUEUE':
      // Gardé pour compatibilité ascendante
      sendResponse({ ok: true });
      return true;

    case 'TRIGGER_PRICE_DROP':
      sendToVinted({ type: 'DO_PRICE_DROP', item: msg.item });
      sendResponse({ ok: true });
      return true;

    case 'TYPE_IN_CATEGORY':
      chrome.tabs.query({ url: ['https://www.vinted.fr/*','https://www.vinted.be/*'] }, async tabs => {
        if (tabs.length > 0) {
          const ok = await typeInCategoryDebugger(tabs[0].id, msg.text);
          sendResponse({ ok });
        } else { sendResponse({ ok: false }); }
      });
      return true;

    case 'STOP_ALL':
      chrome.storage.local.set({ queue: [], publishQueue: [] });
      chrome.alarms.clearAll();
      chrome.alarms.create('checkPriceDrops', { periodInMinutes: 60 });
      sendResponse({ ok: true });
      return true;

    case 'ACTION_DONE':
      chrome.storage.local.get(['stats','log','syncedListings','publishQueue','syncedStock'], data => {
        const stats = resetDay(data.stats);
        if (msg.action === 'message') stats.msgSent++;
        if (msg.action === 'offer') stats.offersSent++;
        if (msg.action === 'offer_accepted') stats.offersAccepted++;
        if (msg.action === 'sale_detected') stats.salesDetected++;
        const log = [{ ...msg, ts: new Date().toISOString() }, ...(data.log||[])].slice(0, 200);
        
        // Si publication → retire de la file, met à jour stock, enchaîne
        if (msg.action === 'published') {
          const publishQueue = (data.publishQueue || []).filter(l => l.titre !== msg.target);
          const syncedListings = (data.syncedListings || []).filter(l => l.result?.titre !== msg.target);
          
          // Marque l'article dans syncedStock comme "publie" (brouillon prêt)
          const syncedStock = (data.syncedStock || []).map(s =>
            s.titre === msg.target ? { ...s, statut: 'en_vente', publie: true } : s
          );

          // Stocke les titres publiés de façon permanente (survit au re-sync)
          chrome.storage.local.get('publishedTitles', ({ publishedTitles }) => {
            const updatedPublished = [...new Set([...(publishedTitles||[]), msg.target].filter(Boolean))];
            chrome.storage.local.set({ stats, log, publishQueue, syncedListings, syncedStock, publishedTitles: updatedPublished });
          });
          notify('✅ Brouillon sauvegardé !', msg.target || 'Article prêt sur Vinted');

          // ── Sync Supabase : marque/crée l'article en_vente ─────────────────
          // Récupère les données complètes de l'article depuis la file ou les listings
          const queueItem = (data.publishQueue || []).find(l => l.titre === msg.target);
      const syncItem = (data.syncedListings || []).find(l => l.result?.titre === msg.target);
      const listingData = queueItem 
        ? { ...queueItem }
        : syncItem 
          ? { ...syncItem.result, photo: syncItem.photo || syncItem.result?.photo || '' }
          : null;
          // Try both session formats
          chrome.storage.local.get(['supabase_session','supabaseToken','supabaseUserId'], (sess) => {
            const session = sess.supabase_session || {
              access_token: sess.supabaseToken,
              user: { id: sess.supabaseUserId }
            };
            if (session?.access_token && session?.user?.id && msg.target) {
              markStockAsEnVente(msg.target, session, listingData).then(ok => {
                if (ok) {
                  notify('📦 Stock mis à jour !', `${msg.target} → En vente`);
                  // Notifie l'app ListAI de recharger le stock
                  chrome.tabs.query({ url: ['https://listai-pro-virid.vercel.app/*'] }, tabs => {
                    if (tabs.length > 0) {
                      chrome.tabs.sendMessage(tabs[0].id, { type: 'LISTAI_REFRESH_STOCK' }).catch(()=>{});
                      // Fallback: injecte du JS pour forcer un reload du stock
                      chrome.scripting.executeScript({
                        target: { tabId: tabs[0].id },
                        func: (titre) => {
                          window.dispatchEvent(new CustomEvent('listai_stock_updated', { detail: { titre } }));
                          console.log('[ListAI Extension] Stock mis à jour:', titre);
                        },
                        args: [msg.target]
                      }).catch(()=>{});
                    }
                  });
                }
              });
            } else {
              console.warn('[ListAI] Session manquante pour sync stock');
              // Essaie quand même avec la clé anon pour lire - peut échouer si RLS activé
              notify("⚠️ Sync stock", "Fais un Sync depuis l'extension puis refresh l'app");
            }
          });

          // Enchaîne la file si demandé
          if (msg.triggerNext) {
            if (publishQueue.length > 0) {
              const delay = 30;
              chrome.alarms.create('processPublish', { delayInMinutes: delay / 60 });
              notify('ListAI Pro ✦', `Prochain article dans ${delay}s — ${publishQueue.length} restant(s)`);
            } else {
              notify('ListAI Pro ✦', '🎉 Tous les articles ont été publiés !');
            }
          }
        } else {
          chrome.storage.local.set({ stats, log });
        }
      });
      return true;

    case 'CLEAR_ALERTS':
      chrome.storage.local.set({ alerts: [] });
      sendResponse({ ok: true });
      return true;
  }
});

// ── ALARMES ───────────────────────────────────────────────────────────────────
chrome.alarms.onAlarm.addListener(alarm => {

  if (alarm.name === 'processQueue') {
    chrome.storage.local.get(['queue','settings','stats'], data => {
      if (!data.queue?.length || !data.settings?.autoMessages) return;
      const stats = resetDay(data.stats);
      if (stats.msgSent >= (data.settings.dailyLimit||50)) return;
      const [current, ...rest] = data.queue;
      chrome.storage.local.set({ queue: rest, stats });
      sendToVinted({ type: 'PROCESS_ITEM', item: current, settings: data.settings });
      if (rest.length > 0) chrome.alarms.create('processQueue', { delayInMinutes: data.settings.delayBetween / 60000 });
    });
  }

  if (alarm.name === 'processPublish') {
    chrome.storage.local.get('publishQueue', ({ publishQueue }) => {
      if (!publishQueue?.length) {
        notify('ListAI Pro ✦', '🎉 Tous les articles ont été publiés !');
        return;
      }
      // Prend le premier SANS le retirer (ACTION_DONE s'en charge)
      const current = publishQueue[0];
      const remaining = publishQueue.slice(1);
      // Met à jour la file ET le pendingListing
      chrome.storage.local.set({ pendingListing: current, publishMode: 'direct' });
      notify('ListAI Pro ✦', `📝 Publication: "${(current.titre||'').slice(0,30)}" (${publishQueue.length} restant(s))`);
      chrome.tabs.query({ url: ['https://www.vinted.fr/*','https://www.vinted.be/*'] }, tabs => {
        if (tabs.length > 0) {
          const tab = tabs[0];
          // Force navigation vers /items/new même si déjà dessus
          chrome.tabs.update(tab.id, { url: 'https://www.vinted.fr/items/new' });
        } else {
          chrome.tabs.create({ url: 'https://www.vinted.fr/items/new' });
        }
      });
    });
  }

  if (alarm.name === 'checkPriceDrops') {
    chrome.storage.local.get(['priceDropSchedule','settings'], data => {
      if (!data.settings?.autoPriceDrop) return;
      const now = Date.now();
      const due = (data.priceDropSchedule||[]).filter(item => item.nextDrop <= now);
      due.forEach(item => sendToVinted({ type: 'DO_PRICE_DROP', item }));
      const updated = (data.priceDropSchedule||[]).map(item =>
        item.nextDrop <= now ? { ...item, nextDrop: now + item.intervalDays * 864e5 } : item
      );
      chrome.storage.local.set({ priceDropSchedule: updated });
    });
  }
});

// ── HELPERS ───────────────────────────────────────────────────────────────────
function sendToVinted(msg) {
  chrome.tabs.query({ url: ['https://www.vinted.fr/*','https://www.vinted.be/*'] }, tabs => {
    if (tabs.length > 0) chrome.tabs.sendMessage(tabs[0].id, msg);
  });
}

function resetDay(stats) {
  if (!stats || stats.today !== today()) return { msgSent:0, offersSent:0, offersAccepted:0, salesDetected:0, today:today() };
  return { ...stats };
}

function checkStaleItems(stock) {
  const alerts = [];
  const now = Date.now();
  stock.filter(s => s.statut === 'en_vente').forEach(s => {
    const added = new Date(s.dateAjout || s.date_ajout || '').getTime();
    const days = isNaN(added) ? 0 : (now - added) / 864e5;
    if (days >= 14) alerts.push({ type: 'stale', titre: s.titre, days: Math.floor(days), id: s.id });
  });
  if (alerts.length > 0) {
    chrome.storage.local.get('alerts', ({ alerts: existing }) => {
      chrome.storage.local.set({ alerts: [...alerts, ...(existing||[])].slice(0, 20) });
    });
    notify('⚠️ Articles sans activité', `${alerts.length} article(s) en vente depuis +14 jours`);
  }
}

function notify(title, message) {
  chrome.notifications.create({ type:'basic', iconUrl:'icons/icon48.png', title, message });
}
