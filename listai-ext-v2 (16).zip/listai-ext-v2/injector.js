// ── LISTAI PRO v2 — Injector (chrome.debugger) ───────────────────────────────

async function typeInCategory(tabId, text) {
  return new Promise(async (resolve) => {
    try {
      // Attache le debugger
      await chrome.debugger.attach({ tabId }, '1.3');
      await new Promise(r => setTimeout(r, 500));

      // Focus sur #catalog-search-input via JS
      await chrome.debugger.sendCommand({ tabId }, 'Runtime.evaluate', {
        expression: `
          (function() {
            const el = document.querySelector('#catalog-search-input');
            if (el) { el.focus(); return true; }
            return false;
          })()
        `
      });
      await new Promise(r => setTimeout(r, 500));

      // Tape chaque caractère via Input.dispatchKeyEvent
      for (const char of text) {
        await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
          type: 'keyDown', key: char, text: char
        });
        await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
          type: 'char', key: char, text: char
        });
        await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
          type: 'keyUp', key: char, text: char
        });
        await new Promise(r => setTimeout(r, 100));
      }

      await new Promise(r => setTimeout(r, 2000));

      // Clique sur le premier résultat
      await chrome.debugger.sendCommand({ tabId }, 'Runtime.evaluate', {
        expression: `
          (function() {
            const items = Array.from(document.querySelectorAll('li, [role="option"]')).filter(el =>
              el.offsetParent && el.textContent.trim().length > 1 &&
              !el.textContent.includes('Trouver')
            );
            if (items.length > 0) { items[0].click(); return items[0].textContent.trim(); }
            return null;
          })()
        `
      });

      await new Promise(r => setTimeout(r, 500));
      await chrome.debugger.detach({ tabId });
      resolve(true);
    } catch (e) {
      try { await chrome.debugger.detach({ tabId }); } catch {}
      console.warn('[ListAI] debugger error:', e);
      resolve(false);
    }
  });
}

// Écoute les messages du background
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'TYPE_CATEGORY') {
    chrome.tabs.query({ url: ['https://www.vinted.fr/*'] }, async (tabs) => {
      if (tabs.length > 0) {
        const result = await typeInCategory(tabs[0].id, msg.text);
        sendResponse({ ok: result });
      } else {
        sendResponse({ ok: false });
      }
    });
    return true;
  }
});
