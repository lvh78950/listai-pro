// ── LISTAI PRO v2 — Content Script ───────────────────────────────────────────
(function () {
  'use strict';
  // Reset on each navigation (allows multi-article queue)
  if (window.__listaiLoaded) {
    console.log('[ListAI] Already loaded on this page, skipping init');
    return;
  }
  window.__listaiLoaded = true;

  const wait = ms => new Promise(r => setTimeout(r, ms));
  const rand = (a, b) => Math.floor(Math.random() * (b - a) + a);

  async function waitFor(selector, timeout = 10000) {
    const t = Date.now();
    const selectors = Array.isArray(selector) ? selector : [selector];
    while (Date.now() - t < timeout) {
      for (const s of selectors) {
        const el = document.querySelector(s);
        if (el && el.offsetParent !== null) return el;
      }
      await wait(300);
    }
    // Last try without visibility check
    for (const s of selectors) {
      const el = document.querySelector(s);
      if (el) return el;
    }
    return null;
  }

  async function humanClick(el) {
    if (!el) return;
    el.scrollIntoView({ behavior: 'instant', block: 'center' });
    await wait(rand(300, 500));
    el.click();
    await wait(rand(200, 400));
  }

  async function fillInput(el, value) {
    if (!el || value === undefined || value === null) return false;
    const strVal = String(value);
    el.scrollIntoView({ behavior: 'instant', block: 'center' });
    el.focus();
    await wait(200);
    try {
      const isTA = el.tagName === 'TEXTAREA';
      const proto = isTA ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) {
        // Clear first
        setter.call(el, '');
        el.dispatchEvent(new Event('input', { bubbles: true }));
        await wait(100);
        // Set value
        setter.call(el, strVal);
        el.dispatchEvent(new InputEvent('input', { bubbles: true, data: strVal }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
        await wait(300);
        // Verify
        if (el.value !== strVal) {
          // Retry with direct assignment
          el.focus();
          await wait(100);
          setter.call(el, strVal);
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          await wait(200);
        }
        return true;
      }
    } catch(e) { console.warn('[ListAI] fillInput error:', e); }
    // Fallback
    el.value = strVal;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    await wait(300);
    return true;
  }

  // Normalise le titre : évite les tout-majuscules
  function normaliseTitre(t) {
    if (!t) return '';
    if (t === t.toUpperCase()) {
      return t.charAt(0).toUpperCase() + t.slice(1).toLowerCase();
    }
    return t;
  }

  // Clique sur un élément de liste par son texte exact ou partiel
  async function clickItemByText(text, timeout = 5000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const els = document.querySelectorAll('li, [role="option"], [role="menuitem"], .web_ui__Cell__cell, [class*="Cell__cell"]');
      for (const el of els) {
        const txt = el.textContent.trim();
        if ((txt === text || txt.startsWith(text)) && el.offsetParent) {
          el.scrollIntoView({ behavior: 'instant', block: 'center' });
          await wait(200);
          el.click();
          await wait(rand(600, 900));
          return true;
        }
      }
      await wait(300);
    }
    return false;
  }

  // Ouvre un dropdown Vinted par son label et clique sur une valeur
  async function selectDropdown(labelText, valueText) {
    // Cherche la row du formulaire par le label
    const rows = document.querySelectorAll('[class*="FormRow"], [class*="form-row"], .u-flexbox, [class*="Cell"]');
    let dropdownEl = null;

    for (const row of rows) {
      if (row.textContent.includes(labelText)) {
        const clickable = row.querySelector('[class*="dropdown"], [class*="Dropdown"], button, [role="button"]');
        if (clickable) { dropdownEl = clickable; break; }
        // La row elle-même est cliquable
        if (row.offsetParent) { dropdownEl = row; break; }
      }
    }

    // Fallback : cherche directement le texte placeholder
    if (!dropdownEl) {
      const allEls = document.querySelectorAll('[class*="Cell"], [class*="cell"], button, [role="button"]');
      for (const el of allEls) {
        if (el.textContent.includes(`Sélectionne`) && el.textContent.includes(labelText.toLowerCase()) && el.offsetParent) {
          dropdownEl = el; break;
        }
      }
    }

    if (!dropdownEl) return false;

    dropdownEl.scrollIntoView({ behavior: 'instant', block: 'center' });
    await wait(500);
    dropdownEl.click();
    await wait(1000);

    return await clickItemByText(valueText);
  }

  // ── CATEGORY PATHS ────────────────────────────────────────────────────────
  const CATEGORY_PATHS = {
    'baskets':    ['Hommes', 'Chaussures', 'Baskets'],
    'sneakers':   ['Hommes', 'Chaussures', 'Baskets'],
    'chaussures': ['Hommes', 'Chaussures', 'Baskets'],
    'boots':      ['Hommes', 'Chaussures', 'Boots & Bottines'],
    't-shirts':   ['Hommes', 'Vêtements', 'T-shirts'],
    't-shirt':    ['Hommes', 'Vêtements', 'T-shirts'],
    'tshirt':     ['Hommes', 'Vêtements', 'T-shirts'],
    'casquettes': ['Hommes', 'Accessoires', 'Chapeaux & Casquettes'],
    'casquette':  ['Hommes', 'Accessoires', 'Chapeaux & Casquettes'],
    'ceintures':  ['Hommes', 'Accessoires', 'Ceintures'],
    'ceinture':   ['Hommes', 'Accessoires', 'Ceintures'],
    'veste':      ['Hommes', 'Vêtements', 'Vestes & Manteaux'],
    'vestes':     ['Hommes', 'Vêtements', 'Vestes & Manteaux'],
    'manteau':    ['Hommes', 'Vêtements', 'Vestes & Manteaux'],
    'jean':       ['Hommes', 'Vêtements', 'Jeans'],
    'jeans':      ['Hommes', 'Vêtements', 'Jeans'],
    'pull':       ['Hommes', 'Vêtements', 'Pulls & Sweats'],
    'sweat':      ['Hommes', 'Vêtements', 'Pulls & Sweats'],
    'hoodie':     ['Hommes', 'Vêtements', 'Pulls & Sweats'],
    'chemise':    ['Hommes', 'Vêtements', 'Chemises'],
    'short':      ['Hommes', 'Vêtements', 'Shorts'],
    'sac':        ['Hommes', 'Accessoires', 'Sacs'],
    'pantalon':   ['Hommes', 'Vêtements', 'Pantalons'],
    'jogging':    ['Hommes', 'Vêtements', 'Pantalons'],
    'polo':       ['Hommes', 'Vêtements', 'Polos'],
    'costume':    ['Hommes', 'Vêtements', 'Costumes & Blazers'],
    'blazer':     ['Hommes', 'Vêtements', 'Costumes & Blazers'],
    // Femmes
    'robe':       ['Femmes', 'Vêtements', 'Robes'],
    'jupe':       ['Femmes', 'Vêtements', 'Jupes'],
    'top':        ['Femmes', 'Vêtements', 'Tops & T-shirts'],
  };

  function getCategoryPath(listing) {
    const catKey = (listing.sous_categorie || listing.categorie || '').toLowerCase();
    const titleKey = (listing.titre || '').toLowerCase();
    for (const [key, path] of Object.entries(CATEGORY_PATHS)) {
      if (catKey.includes(key) || titleKey.includes(key)) return path;
    }
    return null;
  }

  // ── NAVIGATE CATEGORY ─────────────────────────────────────────────────────
  async function navigateCategory(catPath) {
    if (!catPath) return false;

    // Clique sur le dropdown Catégorie
    const catRow = Array.from(document.querySelectorAll('[class*="Cell"], [class*="cell"], button, [role="button"]'))
      .find(el => el.textContent.includes('Sélectionne une catégorie') && el.offsetParent);

    if (!catRow) return false;

    catRow.scrollIntoView({ behavior: 'instant', block: 'center' });
    await wait(500);
    catRow.click();
    await wait(1200);

    // Navigue chaque niveau
    for (const step of catPath) {
      const ok = await clickItemByText(step, 4000);
      if (!ok) {
        console.warn('[ListAI] Catégorie non trouvée:', step);
        return false;
      }
      await wait(rand(800, 1200));
    }
    return true;
  }

  // ── FILL FORM SIMPLIFIÉ : Titre + Description + Prix + Sauvegarde ──────────
  async function fillForm(listing) {
    console.log('[ListAI] fillForm démarré:', listing.titre);
    await wait(2500);

    // 1. TITRE
    showOverlay('✍️ Remplissage du titre...', listing.titre?.slice(0, 40));
    const titleEl = await waitFor(
      ['#title', 'input[name="title"]', 'input[placeholder*="titre"]',
       'input[placeholder*="Titre"]', 'input[data-testid*="title"]',
       'textarea[name="title"]', '[id*="title"]'],
      8000
    );
    if (titleEl) {
      await fillInput(titleEl, normaliseTitre(listing.titre));
      console.log('[ListAI] Titre rempli ✓');
    } else {
      console.warn('[ListAI] Champ titre introuvable');
    }
    await wait(rand(400, 600));

    // 2. DESCRIPTION
    showOverlay('📝 Description...', 'Remplissage...');
    const descEl = await waitFor(
      ['#description', 'textarea[name="description"]',
       'textarea[placeholder*="escription"]', '[data-testid*="description"]',
       'textarea[id*="desc"]'],
      8000
    );
    if (descEl) {
      await fillInput(descEl, listing.description);
      console.log('[ListAI] Description remplie ✓');
    } else {
      console.warn('[ListAI] Champ description introuvable');
    }
    await wait(rand(400, 600));

    // 3. PRIX
    showOverlay('💰 Prix...', `${listing.prix_recommande || listing.prix}€`);
    const priceEl = await waitFor(
      ['#price', 'input[name="price"]', 'input[placeholder*="Prix"]',
       'input[placeholder*="prix"]', 'input[type="number"]',
       '[data-testid*="price"] input', 'input[id*="price"]'],
      8000
    );
    if (priceEl) {
      priceEl.scrollIntoView({ behavior: 'instant', block: 'center' });
      await wait(rand(300, 500));
      // Nettoie la valeur prix — essaie tous les champs possibles
      let priceValue = '';
      const prixFields = [listing.prix_recommande, listing.prix, listing.prix_mini];
      for (const pf of prixFields) {
        if (pf !== undefined && pf !== null && pf !== '') {
          const cleaned = String(pf).replace(/[^0-9.,]/g,'').replace(',','.').trim();
          if (cleaned && cleaned !== '0' && !isNaN(parseFloat(cleaned))) {
            priceValue = cleaned;
            break;
          }
        }
      }
      console.log('[ListAI] Prix brut:', prixFields, '→ utilisé:', priceValue);
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      if (nativeSetter) {
        priceEl.focus();
        await wait(200);
        priceEl.select();
        await wait(100);
        nativeSetter.call(priceEl, '');
        priceEl.dispatchEvent(new InputEvent('input', { bubbles: true, data: '' }));
        await wait(150);
        for (const char of priceValue) {
          priceEl.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true }));
          nativeSetter.call(priceEl, priceEl.value + char);
          priceEl.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: char }));
          priceEl.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));
          await wait(50);
        }
        priceEl.dispatchEvent(new Event('change', { bubbles: true }));
        priceEl.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
        await wait(300);
        // Vérification
        if (!priceEl.value || priceEl.value === '0' || priceEl.value === '') {
          nativeSetter.call(priceEl, priceValue);
          priceEl.dispatchEvent(new Event('input', { bubbles: true }));
          priceEl.dispatchEvent(new Event('change', { bubbles: true }));
          priceEl.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
          await wait(200);
        }
        console.log('[ListAI] Prix rempli ✓ :', priceEl.value);
      } else {
        priceEl.value = priceValue;
        priceEl.dispatchEvent(new Event('input', { bubbles: true }));
        priceEl.dispatchEvent(new Event('change', { bubbles: true }));
        priceEl.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
      }
      await wait(rand(400, 600));
    }

    // 4. SAUVEGARDER LE BROUILLON
    showOverlay('💾 Sauvegarde...', 'Dans 2 secondes...');
    await wait(2000);
    for (const btn of document.querySelectorAll('button, [role="button"]')) {
      if (btn.textContent.trim() === 'Sauvegarder le brouillon' && btn.offsetParent) {
        await humanClick(btn);
        showOverlay('✅ Brouillon sauvegardé !', '📸 Ajoute tes photos puis clique "Ajouter" !');
        // Mise à jour du stock dans Supabase via l'app
        const stockUpdate = async () => {
          try {
            const stored = await chrome.storage.local.get(['supabaseUrl','supabaseKey','supabaseToken']);
            const SUPA_URL = stored.supabaseUrl || 'https://csdbtnfachdxafczqnal.supabase.co';
            const SUPA_KEY = stored.supabaseKey || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNzZGJ0bmZhY2hkeGFmY3pxbmFsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUxNjU1NzcsImV4cCI6MjA2MDc0MTU3N30.Ke7A3VKkUOWNpgcRoHOTWbSCQdRyeovAXHqHJkFSJ-c';
            if (!stored.supabaseToken || !listing.stockId) return;
            // Met à jour le statut de l'article dans le stock → "en_vente"
            await fetch(`${SUPA_URL}/rest/v1/stock?id=eq.${listing.stockId}`, {
              method: 'PATCH',
              headers: { apikey: SUPA_KEY, Authorization: `Bearer ${stored.supabaseToken}`, 'Content-Type': 'application/json' },
              body: JSON.stringify({ statut: 'en_vente', date_publication: new Date().toISOString() })
            });
            console.log('[ListAI] Stock Supabase mis à jour ✓');
          } catch(e) { console.warn('[ListAI] Stock update error:', e); }
        };
        stockUpdate();

        chrome.runtime.sendMessage({
          type: 'ACTION_DONE',
          action: 'published',
          target: listing.titre,
          price: listing.prix_recommande,
          listingId: listing.id,
          triggerNext: true
        });
        setTimeout(hideOverlay, 8000);
        return;
      }
    }
    showOverlay('⚠️ Clique sur "Sauvegarder le brouillon"', 'Formulaire rempli !');
    setTimeout(hideOverlay, 8000);
  }

  // ── MODE 1 : DIRECT ───────────────────────────────────────────────────────
  async function publishDirect(listing) {
    if (!window.location.href.includes('/items/new')) {
      window.location.href = 'https://www.vinted.fr/items/new';
      return;
    }
    await wait(2000);
    showOverlay('🚀 Publication en cours...', listing.titre);
    await fillForm(listing);
  }

  // ── MODE 2 : AUTO (brouillon avec photos) ────────────────────────────────
  async function publishDraftAuto(listing) {
    if (window.location.href.includes('/member/') || window.location.href.includes('/my/items')) {
      const drafts = [];
      document.querySelectorAll('a[href*="/items/"]').forEach(el => {
        const img = el.querySelector('img');
        const href = el.getAttribute('href');
        if (img && href) {
          const itemId = href.match(/items\/(\d+)/)?.[1];
          if (itemId) drafts.push({ url: `https://www.vinted.fr/items/${itemId}/edit`, imgSrc: img.src });
        }
      });
      if (drafts.length === 0) {
        showOverlay('❌ Aucun brouillon trouvé', 'Crée un brouillon avec photos sur Vinted');
        setTimeout(hideOverlay, 5000); return;
      }
      await chrome.storage.local.set({ pendingListing: listing, publishMode: 'found', draftUrl: drafts[0].url });
      await wait(1000);
      window.location.href = drafts[0].url;
      return;
    }
    if (window.location.href.includes('/edit')) {
      showOverlay('📝 Remplissage du brouillon...', 'Photos déjà présentes ✓');
      await wait(2000);
      await fillForm(listing);
    }
  }

  // ── MODE 3 : MANUEL ───────────────────────────────────────────────────────
  async function publishDraftManual(listing, draftUrl) {
    if (!window.location.href.includes('/edit')) {
      await chrome.storage.local.set({ pendingListing: listing, publishMode: 'manual' });
      window.location.href = draftUrl;
      return;
    }
    showOverlay('📝 Remplissage...', listing.titre);
    await wait(2000);
    await fillForm(listing);
  }

  // ── OVERLAY ───────────────────────────────────────────────────────────────
  function showOverlay(title, sub) {
    let el = document.getElementById('listai-v2-overlay');
    if (!el) { el = document.createElement('div'); el.id = 'listai-v2-overlay'; document.body.appendChild(el); }
    el.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
        <div style="width:28px;height:28px;background:linear-gradient(135deg,#C9A96E,#e8c584);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:14px;color:#1a1a2e;font-weight:900;flex-shrink:0;">✦</div>
        <div style="font-size:14px;font-weight:800;color:#C9A96E;">${title}</div>
      </div>
      <div style="font-size:12px;color:#aaa;line-height:1.5;max-width:280px;">${sub || ''}</div>`;
    el.style.display = 'block';
  }
  function hideOverlay() { const el = document.getElementById('listai-v2-overlay'); if (el) el.style.display = 'none'; }

  // ── SCRAPE FAVORIS ────────────────────────────────────────────────────────
  function scrapeFavorites() {
    const items = [];
    // Multiple selector strategies for Vinted's changing DOM
    const cards = document.querySelectorAll([
      '[data-testid="item-box"]',
      '[class*="ItemBox"]',
      '[class*="item-box"]', 
      'article[class*="item"]',
      '[class*="feed-grid"] > div',
      '[class*="grid"] article'
    ].join(','));
    cards.forEach(card => {
      const link = card.querySelector('a[href*="/items/"]');
      const title = card.querySelector('[class*="title"], [data-testid*="title"], h3, h2');
      const favEl = card.querySelector('[class*="favourite"], [data-testid*="favourite"], [class*="like"], [class*="bookmark"]');
      const priceEl = card.querySelector('[class*="price"], [data-testid*="price"]');
      const isSold = !!(card.querySelector('[class*="sold"], [class*="Sold"]') || card.textContent.includes('Vendu'));
      if (link && !isSold) {
        items.push({ id: link.href.match(/items\/(\d+)/)?.[1] || Date.now().toString(), url: link.href, title: title?.textContent?.trim() || 'Article', favs: parseInt(favEl?.textContent) || 0, price: priceEl?.textContent?.trim() || '?' });
      }
    });
    return items.filter(i => i.favs > 0);
  }

  // ── BAISSE DE PRIX ────────────────────────────────────────────────────────
  // ── Send message to item favorites ──────────────────────────────────────
  async function doSendFavoriteMessage(item, settings) {
    try {
      // Navigate to item page
      if (!window.location.href.includes(`/items/${item.id}`)) {
        window.location.href = `https://www.vinted.fr/items/${item.id}`;
        await wait(3000);
      }
      // Find "Envoyer un message" button
      const msgBtn = Array.from(document.querySelectorAll('button, a')).find(el =>
        el.textContent.toLowerCase().includes('message') ||
        el.textContent.toLowerCase().includes('contacter')
      );
      if (!msgBtn) { console.warn('[ListAI] Bouton message introuvable'); return false; }
      msgBtn.click();
      await wait(1500);
      // Find textarea
      const textarea = document.querySelector('textarea, [contenteditable="true"]');
      if (!textarea) { console.warn('[ListAI] Textarea message introuvable'); return false; }
      const msg = settings.customMessage || "Bonjour ! Je suis intéressé(e) par votre article. Est-il toujours disponible ? 😊";
      await fillInput(textarea, msg);
      await wait(500);
      // Send
      const sendBtn = Array.from(document.querySelectorAll('button')).find(el =>
        el.textContent.toLowerCase().includes('envoyer') || el.textContent.toLowerCase().includes('send')
      );
      if (sendBtn) { sendBtn.click(); await wait(500); }
      chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'message', target: item.id });
      return true;
    } catch(e) { console.error('[ListAI] doSendFavoriteMessage error:', e); return false; }
  }

  async function doPriceDrop(item) {
    showOverlay('📉 Baisse de prix...', item.titre || item.title);
    try {
      const editUrl = (item.url || '').replace(/\/?(\?.*)?$/, '/edit');
      if (!window.location.href.includes('/edit')) {
        await chrome.storage.local.set({ pendingPriceDrop: item });
        window.location.href = editUrl;
        return;
      }
      await wait(2000);
      const currentPrice = parseFloat((item.prix || item.price || '0').replace(/[^0-9.,]/g, '').replace(',', '.'));
      if (isNaN(currentPrice) || currentPrice === 0) throw new Error('Prix illisible');
      const newPrice = Math.max(1, currentPrice * 0.90).toFixed(2);
      const priceEl = await waitFor(
      ['#price', 'input[name="price"]', 'input[placeholder*="Prix"]',
       'input[placeholder*="prix"]', 'input[type="number"]',
       '[data-testid*="price"] input', 'input[id*="price"]'],
      8000
    );
      if (priceEl) { await fillInput(priceEl, newPrice); await wait(rand(500, 800)); }
      for (const btn of document.querySelectorAll('button')) {
        if ((btn.textContent.includes('Enregistrer') || btn.textContent.includes('Sauvegarder')) && btn.offsetParent) {
          await humanClick(btn);
          chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'price_drop', target: item.titre || item.title, price: newPrice });
          showOverlay('✅ Prix baissé !', `${currentPrice}€ → ${newPrice}€`);
          setTimeout(hideOverlay, 4000);
          return;
        }
      }
    } catch (e) { hideOverlay(); console.warn('[ListAI v2] doPriceDrop:', e); }
  }

  // ── MESSAGES ─────────────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
      switch (msg.type) {
        case 'DO_PUBLISH':
          await chrome.storage.local.set({ pendingListing: msg.listing, publishMode: msg.mode || 'direct' });
          if (msg.mode === 'auto') await publishDraftAuto(msg.listing);
          else if (msg.mode === 'manual' && msg.draftUrl) await publishDraftManual(msg.listing, msg.draftUrl);
          else await publishDirect(msg.listing);
          sendResponse({ ok: true }); break;
        case 'DO_PRICE_DROP':
        case 'PROCESS_ITEM':
          // Send message to item owner if autoMessages enabled
          if (msg.settings?.autoMessages && msg.item?.id) {
            await doSendFavoriteMessage(msg.item, msg.settings);
          } else {
            await doPriceDrop(msg.item);
          }
          sendResponse({ ok: true }); break;
        case 'SCAN_FAVORITES':
          sendResponse({ items: scrapeFavorites() }); break;
        case 'SCAN_FOR_ACTIVITY':
          // Scan current page for offers and messages
          const activity = { offers: [], messages: [] };
          // Check notifications
          document.querySelectorAll('[class*="notification"], [class*="Notification"]').forEach(n => {
            const text = n.textContent.trim();
            if (text.includes('offre') || text.includes('offer')) activity.offers.push({ text });
            if (text.includes('message')) activity.messages.push({ text });
          });
          chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'scan', target: `${activity.offers.length} offres, ${activity.messages.length} messages` });
          sendResponse({ activity }); break;
        case 'GET_DRAFTS':
          const drafts = [];
          document.querySelectorAll('a[href*="/items/"]').forEach(el => {
            const img = el.querySelector('img');
            if (img && el.href.includes('/edit')) drafts.push({ url: el.href, imgSrc: img.src, title: img.alt || 'Brouillon' });
          });
          sendResponse({ drafts }); break;
      }
    })();
    return true;
  });

  // ── INIT ─────────────────────────────────────────────────────────────────
  (async () => {
    // Attendre que Vinted React soit prêt (retry jusqu'à 8s)
    let data = null;
    for (let attempt = 0; attempt < 4; attempt++) {
      await wait(2000);
      data = await chrome.storage.local.get(['pendingListing', 'pendingPriceDrop', 'publishMode']);
      if (data.pendingListing) break;
    }
    console.log('[ListAI] Content script sur:', window.location.href, '| pending:', !!data?.pendingListing);

    if (data?.pendingListing) {
      const listing = data.pendingListing;
      const mode = data.publishMode || 'direct';
      // ⚠️ Ne PAS supprimer pendingListing avant d'être sur la bonne page
      // On le supprime seulement juste avant fillForm pour éviter double-fill

      if (window.location.href.includes('/items/new') && mode === 'direct') {
        // On est sur la bonne page → on remplit
        await chrome.storage.local.remove(['pendingListing', 'publishMode']);
        await publishDirect(listing);
      } else if (window.location.href.includes('/edit') && (mode === 'manual' || mode === 'found')) {
        await chrome.storage.local.remove(['pendingListing', 'publishMode']);
        await publishDraftManual(listing, window.location.href);
      } else if ((window.location.href.includes('/member/') || window.location.href.includes('/my/items')) && mode === 'auto') {
        await chrome.storage.local.set({ pendingListing: listing, publishMode: 'auto' });
        await publishDraftAuto(listing);
      } else if (window.location.href.includes('/edit') && mode === 'auto') {
        await chrome.storage.local.remove(['pendingListing', 'publishMode']);
        await publishDraftAuto(listing);
      } else if (mode === 'direct') {
        // Pas encore sur /items/new → navigue et garde pendingListing en storage
        console.log('[ListAI] Navigation vers /items/new avec pendingListing conservé...');
        // pendingListing reste dans storage — la nouvelle page le lira
        window.location.href = 'https://www.vinted.fr/items/new';
      }
    }

    if (data?.pendingPriceDrop && window.location.href.includes('/edit')) {
      await chrome.storage.local.remove('pendingPriceDrop');
      await doPriceDrop(data.pendingPriceDrop);
    }
  })();

})();
